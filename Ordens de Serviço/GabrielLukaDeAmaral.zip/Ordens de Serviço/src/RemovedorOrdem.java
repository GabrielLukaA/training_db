public interface RemovedorOrdem {
    boolean deletarOrdem(int numeroOrdem);
}
