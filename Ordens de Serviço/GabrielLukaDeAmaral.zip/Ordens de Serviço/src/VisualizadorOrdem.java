public interface VisualizadorOrdem {

    String verOrdens();
}
