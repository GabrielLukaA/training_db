public interface CriadorOrdem {

        void criarOrdem(OrdemDeServico ordem);

}
