public interface EditorOrdem {
    OrdemDeServico editarOrdem(int numeroOrdem, OrdemDeServico ordem);
}
